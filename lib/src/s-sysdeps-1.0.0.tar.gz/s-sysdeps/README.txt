Please consult the documentation in the doc directory, starting with index.html
