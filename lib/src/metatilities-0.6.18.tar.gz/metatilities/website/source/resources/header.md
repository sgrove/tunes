{set-property html yes}
{set-property style-sheet "http://common-lisp.net/project/cl-containers/shared/style-200.css"}
{set-property author "Gary Warren King"}

<div class="header">
	<span class="logo">
	    <a href="http://www.metabang.com/" title="metabang.com">
	        <img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" 
	             title="metabang.com" width="100" alt="Metabang Logo" /></a>
	    </span>

## Metatilities

#### Now where is that kitchen sink...

</div>

  [tr]: test-report.html

  [darcs]: http://www.darcs.net/
  [asdf-install]: http://common-lisp.net/project/asdf-install
  [tarball]: http://common-lisp.net/project/cl-containers/bundler/bundler_latest.tar.gz
  [gwking]: http://www.metabang.com/
  [bundler-cliki]: http://www.cliki.net/bundler
  [ASDF-Extension]: http://www.cliki.net/asdf-extension
  [gwking-mail]: mailto:gwking@metabang.com
  
  [CL-Markdown]: http://common-lisp.net/project/cl-markdown/
  [asdf-install]: http://www.cliki.net/asdf-install
  [trivial-shell-cliki]: http://www.cliki.net/trivial-shell
  [trivial-shell-tar]: http://common-lisp.net/project/trivial-shell/trivial-shell_latest.tar.gz


  [8]: http://common-lisp.net/cgi-bin/mailman/listinfo/trivial-shell-announce
  [9]: http://common-lisp.net/cgi-bin/mailman/listinfo/trivial-shell-devel

  [1]: http://common-lisp.net/project/cl-containers/shared/metabang-2.png (metabang.com)
  [2]: http://www.metabang.com/ (metabang.com)


