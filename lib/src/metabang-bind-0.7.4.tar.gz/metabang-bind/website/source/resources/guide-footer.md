<div id="footer">
<span id="copyright"> Copyright (c) 2005 - 2007 Gary Warren King (gwking@metabang.com)</span> 
<span id="license-note">metabang-bind has an MIT style license</span>
<span id="timestamp">Last updated {today} at {now}</span>
</div>

