 [darcs]: http://www.darcs.net/
 [asdf-install]: http://common-lisp.net/project/asdf-install
 [gwking]: http://www.metabang.com/

 [Home]: index.html
 [user-guide]: user-guide.html

 [bundler-cliki]: http://www.cliki.net/bundler
 [ASDF-Extension]: http://www.cliki.net/asdf-extension
 [gwking-mail]: mailto:gwking@metabang.com
 
 [CL-Markdown]: http://common-lisp.net/project/cl-markdown/
 [asdf-install]: http://www.cliki.net/asdf-install
 [metabang-bind-cliki]: http://www.cliki.net/metabang-bind

 [metabang-bind-devel]: http://common-lisp.net/cgi-bin/mailman/listinfo/metabang-bind-devel
