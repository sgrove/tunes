{set-property html yes}
{set-property style-sheet user-guide}
{set-property author "Gary Warren King"}

<div id="header">
{include resources/navigation.md}
</div>

{include resources/shared.md}
