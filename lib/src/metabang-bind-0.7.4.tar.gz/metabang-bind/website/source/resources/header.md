{set-property html yes}
{set-property style-sheet "http://common-lisp.net/project/cl-containers/shared/style-200.css"}
{set-property author "Gary Warren King"}

{include resources/shared.md}

<div class="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## metabang-bind

#### Sticking the pedal to the metal fun

</div>

  [tr]: test-report.html

  [darcs]: http://www.darcs.net/
  [asdf-install]: http://common-lisp.net/project/asdf-install
  [tarball]: http://common-lisp.net/project/cl-containers/bundler/bundler_latest.tar.gz
  [gwking]: http://www.metabang.com/
  [bundler-cliki]: http://www.cliki.net/bundler
  [ASDF-Extension]: http://www.cliki.net/asdf-extension
  [gwking-mail]: mailto:gwking@metabang.com
  
  [CL-Markdown]: http://common-lisp.net/project/cl-markdown/
  [asdf-install]: http://www.cliki.net/asdf-install
  [metabang-bind-cliki]: http://www.cliki.net/metabang-bind
  [metabang-bind-tar]: http://common-lisp.net/project/metabang-bind/metabang-bind_latest.tar.gz


  [8]: http://common-lisp.net/cgi-bin/mailman/listinfo/metabang-bind-announce
  [9]: http://common-lisp.net/cgi-bin/mailman/listinfo/metabang-bind-devel

  [1]: http://common-lisp.net/project/cl-containers/shared/metabang-2.png (metabang.com)
  [2]: http://www.metabang.com/ (metabang.com)


