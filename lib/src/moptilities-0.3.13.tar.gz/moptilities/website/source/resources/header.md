{include shared-links.md}

{set-property html yes}
{set-property style-sheet "http://common-lisp.net/project/cl-containers/shared/style.css"}
{set-property author "Gary Warren King"}
  
 [devel-list]: http://common-lisp.net/cgi-bin/mailman/listinfo/moptilities-devel
 [cliki-home]: http://www.cliki.net/moptilities
 [tarball]: http://common-lisp.net/project/moptilities/moptilities.tar.gz
 [project-documentation]: documentation
 
<div class="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## Moptilities

#### Zany and Zippy yet never Oozy

</div>
