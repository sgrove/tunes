{include shared-links.md}

{set-property html yes}
{set-property style-sheet "http://common-lisp.net/project/cl-containers/shared/style-200.css"}
{set-property author "Gary Warren King"}

[devel-list]: http://common-lisp.net/cgi-bin/mailman/listinfo/metatilities-base-devel
[cliki-home]: http://www.cliki.net/metatilities-base
[tarball]: http://common-lisp.net/project/metatilities-base/metatilities-base.tar.gz
  
<div class="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## CL-Containers

#### More fun than kissing bunnies!

</div>
