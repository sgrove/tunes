{set-property html yes}
{set-property style-sheets "http://common-lisp.net/project/cl-containers/shared/style-200.css" "user-guide.css"}
{set-property author "Gary Warren King"}
{include shared-links.md}
  
<div class="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## CL-Containers

#### More fun than kissing bunnies!

</div>

